package com.itproger;

public class Child extends Base {

    @MyAnnotation
    public int number;

    @MyAnnotation
    Child() {}

    @Override
    @Deprecated
    @MyAnnotation
    public void print(@MyAnnotation String info) {
        System.out.println("Результат: " + info);
    }

}
