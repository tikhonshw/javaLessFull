package com.itproger;

public class Main {

    public static void main(String[] args) {
        Child obj = new Child();
        obj.print("");
    }
}
