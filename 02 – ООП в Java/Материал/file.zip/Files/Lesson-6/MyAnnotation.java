package com.itproger;

import java.lang.annotation.*;

// @Target(ElementType.CONSTRUCTOR)
@Inherited
@Retention(RetentionPolicy.RUNTIME)
public @interface MyAnnotation {

    int number() default 5;
    String name() default "Bob";
    float digit() default 4.5f;

    enum Types { Basic, Middle, Hard }
    Types type() default Types.Hard;

}
