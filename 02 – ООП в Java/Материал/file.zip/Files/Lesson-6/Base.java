package com.itproger;

@MyAnnotation
public class Base {

    protected void print(String info) {
        System.out.println(info);
    }

}
