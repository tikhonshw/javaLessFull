package com.itProger;

public enum Personality {
    FEMALE,
    MALE,
    ALIEN
}
