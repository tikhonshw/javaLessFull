package com.itProger;

public enum Days {
    MONDAY,
    TUESDAY
}
