package com.itProger;

public class TestClass  implements SomeInterface, HumanInreface {

    @Override
    public void Test() {

    }

    @Override
    public String getString(String word) {
        return null;
    }

    @Override
    public void talk() {

    }

    @Override
    public void walk() {

    }

    @Override
    public int getAge() {
        return 0;
    }
}
