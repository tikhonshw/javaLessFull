package com.itProger;

public class SimpleClass extends TestClass {
}
