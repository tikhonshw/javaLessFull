package com.itProger;

public interface HumanInreface {
    void talk();
    void walk();
    int getAge();
}
