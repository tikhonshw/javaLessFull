package com.itProger;

public interface SomeInterface {
    void Test();
    String getString(String word);
}
