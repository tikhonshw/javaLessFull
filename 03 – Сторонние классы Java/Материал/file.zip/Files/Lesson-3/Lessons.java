package com.itProger;

public class Lessons extends Course {

    public Lessons(int id, String title) {
        super(id, title);
    }

}
