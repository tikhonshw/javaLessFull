package com.itProger;

@FunctionalInterface
public interface IMath {

    double summ(double a, double b);

}
